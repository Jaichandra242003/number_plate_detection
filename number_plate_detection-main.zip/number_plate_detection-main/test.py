import cv2 as cv
import matplotlib.pyplot as plt
image=cv.imread("car10.jpg")
print("HEllo")
plt.imshow(image)